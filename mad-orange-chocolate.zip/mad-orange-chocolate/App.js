import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Image } from 'react-native';

function FormularioLogin({ navigation }) {
  const [nombre, setNombre] = useState('correo@mail.com');
  const [password, setPassword] = useState('1234567890');

  const handleSubmit = () => {
    let reg = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;

    let valido = false;

    // Validation
    if (nombre.length <= 0) {
      console.log('Debe ingresar el nombre de usuario');
     
    }

    // Validate email format
    if (reg.test(nombre) === false) {
      console.log('El correo no es válido');
    
    }
    else{
      console.log("correo valido");
      console.log("nombre");
      valido=true;
    }

    // Validate password length
     if (password === '') {
      alerta('Debe ingresar una contraseña')
      console.log('La contraseña debe tener al menos 8 caracteres');
      valido = false;
    }
    if (password.length < 8) {
      console.log('La contraseña debe tener al menos 8 caracteres');
      valido = false;
    }

    if (valido) {
      // Navigate to another screen or perform login action
      console.log('Formulario válido');
      // Example: navigation.navigate('Home');
    }
  };

  return (
    <View style={styles.container}>
      <Text>Correo Electrónico:</Text>
      <TextInput
        style={styles.input}
        onChangeText={setNombre}
        value={nombre}
        placeholder="Ingrese su correo"
        keyboardType="email-address"
      />
      <Text>Contraseña:</Text>
      <TextInput
        style={styles.input}
        onChangeText={setPassword}
        value={password}
        placeholder="Ingrese su contraseña"
        secureTextEntry
      />
      <Button title="Iniciar Sesión" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
});

export default FormularioLogin;